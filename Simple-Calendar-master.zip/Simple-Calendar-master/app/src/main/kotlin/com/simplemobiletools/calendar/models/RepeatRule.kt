package com.simplemobiletools.calendar.models

data class RepeatRule(val repeatInterval: Int, val repeatRule: Int, val repeatLimit: Int)
